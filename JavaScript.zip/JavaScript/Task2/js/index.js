// tsk1


function show(){
    document.write("<h1>INDHU</h2>")
    document.write("<h2>27</h2>")
}
show()

//task2

var num1=2,num2=4,sum
function sum(){
          sum=num1+num2
          document.write(`sum is ${sum}`)
}
sum()

//tak3



function mul(num1,num2){
    var sum=num1*num2
    document.write(`<p>multiplication of 2 number is${sum}</p>`)
}mul(4,5)