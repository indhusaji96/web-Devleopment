let fighters = ["🐉", "🐥", "🐊","💩", "🦍", "🐢", "🐩", "🦭", "🦀", "🐝", "🤖", "🐘", "🐸", "🕷","🐆", "🦕", "🦁"]

// let stageEl = document.getElementById("stage")
// let fightBtn = document.getElementById("fightButton")


var stageEl
var fightBtn
 function fightButton() {
   
    var stageEl= document.getElementById("stage").value
var fightBt=document.getElementById("fightbtn").value
      var data=  fighters[Math.floor(Math.random() * fighters.length)]
    document.getElementById("stage").textContent=data
    var det=  fighters[Math.floor(Math.random() * fighters.length)]

     document.getElementById("fightbtn").textContent=det
}
fightButton()
