
function sum(num1,num2){
         var sum=num1+num2
         return sum; 
}
var data=sum(4,6)
console.log(`sum of the numbers is ${data}`)