var i=1
document.write("<p>print 1-500 using while loop</p>")

while(i<=500){
    document.write(`${i},`)
    i++
}

//  2
var i
document.write("<p>print 1-100 using forloop</p>")

for(i=1;i<=100;i++){
    document.write(`${i},`)
}

// 3
var i 
document.write("<p>print 100-1 using forloop</p>")

for(i=100;i>=1;i--){
    document.write(`${i},`)
 }

//  4

var i
document.write("<p>print even numbers 1-100 using for loop</p>")
for(i=1;i<=100;i++) {
    if(i%2==0){
        document.write(`${i},`)
 
    }
    
}