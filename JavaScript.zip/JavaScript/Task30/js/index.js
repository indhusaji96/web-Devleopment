

function Strength(){
    var password=document.getElementById("pass").value;
    var strong=document.getElementById("data");
    let strongPassword = new RegExp('(?=.*[0-9])(?=.*[^A-Za-z0-9])(?=.{12,})')
    let mediumPassword = new RegExp('(?=.*[0-9])(?=.*[^A-Za-z0-9])')
    if(strongPassword.test(password)) {
        strong.style.color = "green"
        strong.textContent = 'Strong'
      
    } else if(mediumPassword.test(password)){
        strong.style.color = 'blue'
        strong.textContent = 'Medium'
    } else{
        strong.style.color = 'red'
        strong.textContent = 'Weak'
    }
}