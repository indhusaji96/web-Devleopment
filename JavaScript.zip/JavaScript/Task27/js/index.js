
function validateForm(){


var name=document.getElementById("fname").value;
let data;
var letters = /^[A-Za-z]+$/;
if(name==null || name=="") {
    data = "Name can't be blank"
}else if(name.match(letters)){
 
document.getElementById("sentence").innerHTML= "";

  }
   else
     {
      data= "Name should be char"

      document.getElementById("sentence").innerHTML= data;
     }



    var email=document.getElementById('mail').value;

    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    let item;
    if(email.match(mailformat))
    {
     
     
      document.getElementById("memail").innerHTML= " ";
     

    }
    else
    {
    item= "You have entered an invalid email address!";
    document.getElementById("memail").innerHTML=item

    
     }


let x = document.getElementById("pno").value;
let text;
var phoneno = /^\d{10}$/;
            if(x.match(phoneno)){
              text = "Input OK";

  document.getElementById("demo").innerHTML = ""
 
} else {
  text = "Input not valid";

  document.getElementById("demo").innerHTML= text;

}
let elementToMove = document.getElementById('element_to_move');
const element = document.getElementById("element_to_move");
sect.scrollIntoView();

}