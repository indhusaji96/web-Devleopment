var sunblockstock=10
var sunlotionstock=3
var sunscreenstock=5
// var cart=0
// var price=0
var obj={
    blockstock:10,
    lotionstock:3,
    screenstock:5,
    cartcount:0,
    pricedisplay:0
}
var newobj=JSON.stringify(obj);
document.getElementById("dollar").innerText=`$${obj.pricedisplay}`
document.getElementById("two").innerText=obj.cartcount
document.getElementById("stocks").innerHTML=`stock:${obj.blockstock}`
document.getElementById("lotion").innerHTML=`stock:${obj.lotionstock}`
document.getElementById("sunscreen").innerHTML=`stock:${obj.screenstock}`

localStorage.setItem("addtocart",newobj)
function btnaddtocart(){
   if(sunblockstock>0){
    obj.blockstock=sunblockstock--
   obj.cartcount=obj.cartcount++
    obj.pricedisplay=obj.pricedisplay+45
    var obj1=JSON.stringify(obj)

    localStorage.setItem("addtocart",obj1)
  var count=JSON.parse(localStorage.getItem('addtocart'))  

    document.getElementById("two").innerText=count.cartcount

    document.getElementById("stocks").innerHTML=`stock:${count.blockstock}`
    document.getElementById("dollar").innerText=`$${count.pricedisplay}`
  
   }
  else if(sunblockstock===0){
    document.getElementById("popup").style.display="block"
   }

}
function sunlotioncart(){
   if(sunlotionstock>0){
    sunlotionstock--
    cart++
    price=price+35

    document.getElementById("lotion").innerHTML=`stock:${sunlotionstock}`
    document.getElementById("two").innerText=cart
    document.getElementById("dollar").innerText=`$${price}`

   }
   else if(sunlotionstock===0){
    document.getElementById("popup").style.display="block"
   }

}
function sunscreencart(){
    if(sunscreenstock>0){
        sunscreenstock--
     cart++
     price=price+50

     document.getElementById("sunscreen").innerHTML=`stock:${sunscreenstock}`
     document.getElementById("two").innerText=cart
     document.getElementById("dollar").innerText=`$${price}`


    }
    else if(sunscreenstock===0){
        document.getElementById("popup").style.display="block"
       }
 
 
 }
 document.getElementById("btnok").addEventListener("click",function(){
    document.getElementById("popup").style.display="none"
})