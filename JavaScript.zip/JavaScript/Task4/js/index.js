function getRandomNumber(){
    num1=6
    num2=8
    return 5
}

var data=getRandomNumber()
document.write(`<h1>return value${data}</h1>`)
var a=getRandomNumber()
document.write(`num value${a}`)

var b=getRandomNumber()

document.write(`num value${b}`)

