document.getElementById("addTo").addEventListener('click',function(){
    var Data=document.getElementById("data").value
    localStorage.setItem("data",Data)
 
})
document.getElementById("display").addEventListener('click',function(){
    var Data=document.getElementById("data").value
    
    document.getElementById("demo").innerHTML = localStorage.getItem("data",Data);

 
})
document.getElementById("delete").addEventListener('click',function(){
    var Data=document.getElementById("data").value
    localStorage.removeItem("data",Data)
    document.getElementById("demo").innerHTML ="" 
 
})
