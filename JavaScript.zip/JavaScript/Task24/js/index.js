let person={name:"Indhu" , age:27, country:"India"}

function logData(){

    document.getElementById("data").innerHTML =(` ${person.name} is ${person.age} years old and lives in ${person.country}`)
    
}logData()