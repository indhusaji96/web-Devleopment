

function add(){
  
    var numOne, numTwo, sum;

    numOne = parseInt(document.getElementById("fnum").value);
    numTwo = parseInt(document.getElementById("snum").value);
   var sum = numOne + numTwo;
    document.getElementById("sums").value = sum;
    return false
}
function sub(){
    var numOne, numTwo, sum;

    numOne = parseInt(document.getElementById("fnum").value);
    numTwo = parseInt(document.getElementById("snum").value);
   var sum = numOne - numTwo;
    document.getElementById("sums").value = sum;
    return false
}
function div(){
    var numOne, numTwo, sum;

    numOne = parseInt(document.getElementById("fnum").value);
    numTwo = parseInt(document.getElementById("snum").value);
   var sum = numOne / numTwo;
    document.getElementById("sums").value = sum;
    return false
}

function mul(){
    var numOne, numTwo, sum;

    numOne = parseInt(document.getElementById("fnum").value);
    numTwo = parseInt(document.getElementById("snum").value);
   var sum = numOne * numTwo;
    document.getElementById("sums").value = sum;
    return false
}




