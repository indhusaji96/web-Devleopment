

fetch("https://api.unsplash.com/photos/random?orientation=landscape&query=Nature&client_id=x4hP_G_KmXLC-oVwXghkUmHbS7P0UKpw9JtGadnIC7I")
.then(response=>response.json())
.then(data=>{
  console.log(data)
  document.getElementById("image").style.backgroundImage=`url(${data.urls.regular})`
})





navigator.geolocation.getCurrentPosition(showPosition);
   
function showPosition(position) {
    var lat= position.coords.latitude
   var lon=  position.coords.longitude

 fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=a744fac2652f679a89d0642ba1446e82`)
     .then((response) => {
       return response.json();
     })
     .then((data) => {
       console.log(data);
      document.getElementById("weather").innerHTML=`Weather:${data.weather[0].main}`
      document.getElementById("city").innerHTML=`City:${data.name}`
      document.getElementById("temperature").innerHTML=`Temprature:${data.main.temp}kelvin`
      document.getElementById("wind").innerHTML=`WindSpeed:${data.wind.speed}meter/sec`
      document.getElementById("visibility").innerHTML=`Visibility: ${data.visibility}meter`
      })
      }