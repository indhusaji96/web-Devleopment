

var data=document.getElementById('add').value
var Course=document.getElementById('course').value
if(Course==null){
    var item= [data]

   
    document.getElementById("course").innerHTML=`<li>${data}</li>`
}