let dayOfMonth = 13
let weekday = "Tuesday"

if(dayOfMonth==13 && weekday=="Friday"){
     document.write("😱")
}