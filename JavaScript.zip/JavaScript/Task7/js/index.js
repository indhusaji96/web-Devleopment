var i

for(i=1;i<=10;i++){
    
    var sum=i*10
    console.log(`${sum}`)
}