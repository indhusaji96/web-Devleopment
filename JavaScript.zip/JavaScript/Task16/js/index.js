function display() {
    var num=parseInt(document.getElementById("num").value)
     var meter=(num * 3.280).toFixed(3)
    var feet=(num / 3.280).toFixed(3)
    document.getElementById("length").innerHTML=`${num}meter=${meter}feet || ${num}feet=${feet}meter`
    var liters=(num * 0.264).toFixed(3)
    var gallons=(num / 0.264).toFixed(3)
    document.getElementById("vol").innerHTML=`${num}liters=${liters}gallons || ${num}gallons=${gallons}liters`

    var kilogram=(num * 2.204).toFixed(3)
    var pound=(num * 2.204).toFixed(3)
    document.getElementById("mass").innerHTML=`${num}kilogram=${kilogram}pound || ${num}pound=${pound}kilogram`



  }