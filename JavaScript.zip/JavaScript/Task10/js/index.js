let largeCountries = ["China","India","USA","Indonesia","Pakistan"]

for(i=0;i<largeCountries.length;i++){
    console.log(largeCountries[i])
}
