let largeCountries = ["Tuvalu","India","USA","Indonesia","Monaco"]


largeCountries.pop()
largeCountries.unshift("china")
largeCountries.push()
largeCountries.shift("pakistan")

console.log(largeCountries)
