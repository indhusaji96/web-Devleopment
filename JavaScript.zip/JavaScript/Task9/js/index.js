var myself=["Indhu", 27, true]
for(i=0;i<myself.length;i++){
    console.log(myself[i])
}