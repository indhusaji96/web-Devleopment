function aswathy(){
    document.getElementById('myImage').src='ft.jpg'
}

function sreya(){
    document.getElementById('myImage').src='first.webp'
}

function arya(){
    document.getElementById('myImage').src='tata.avif'
}