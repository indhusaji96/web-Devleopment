
document.getElementById("yrcountry").addEventListener('click', function () {
    fetch('https://restcountries.com/v3.1/all')
        .then(response =>
            response.json()
        )
        .then(data => {
             console.log(data)
            document.getElementById("imgcountry").style.display = "block"
            for (let index = 0; index < data.length; index++) 
            {
                document.getElementById("imgcountry").innerHTML += `<img class="flag" id="flags" src="${data[index].flags.png}">`; 
               
              
                 }  
                 
                
                  document.getElementById("flags").addEventListener('click',function(){
                     
                    for (let index = 0; index < data.length; index++) {
                            data[index].name.common;
                        
                    
                       
                             if( src = data[index].name.common )
                       {
                        
                        console.log(`${data[index].name.common}`)
                         document.getElementById("countryhead").innerHTML +=`${data[index].name.common}`      
                             
                       }
                    }
                    })
                })
            

                
          
                 
        })
    


