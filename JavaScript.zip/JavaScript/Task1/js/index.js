// tsk1
document.write("<h1>Indhu Saji</h1>")

// tsk2
var num1=10
var num2=20 
var sum=num1+num2
document.write(`<h2>sum of 2 variable is ${sum}</h2>`)

// tsk3

console.log("INDHU SAJI")
console.log(27)

// task4
var age=19
document.write("<h4>age=19</h4>")
if(age>=18){
    document.write("Eligible for voting")
}
else{
    document.write("not eligible for voting")
}
// tsk5

var num=-10
if(num==0){
    document.write("<p>number is zero</p>")
}
else if(num>0){
 document.write("<p>number is positive</p>")
}
else{
    document.write("<p>number is negative</p>")
}


// task6

var name="Indhu"
document.write(`<h1>Hello ${name}</h1>`)
