var num=0
document.getElementById("display").innerText=num
document.getElementById("add").addEventListener("click",function(){
    num++
    document.getElementById("display").innerText=num
    if(num>0){
        document.getElementById("sub").disabled=false
        document.getElementById("cart").disabled=false
    }
})
document.getElementById("sub").addEventListener("click",function(){
    num--
    document.getElementById("display").innerText=num
    if(num<=0){
        document.getElementById("sub").disabled=true
        document.getElementById("cart").disabled=true
    }
})