// Create a for loop that logs out all the cards in the array

let cards = [7, 3, 9]

for(let index=0;index<cards.length;index++){
    console.log(cards[index]);
}


let sentence = ["Hello", "my", "name", "is", "Alisha"]
var sent=""
for(let i=0;i<sentence.length;i++){
    var data=sentence[i]
     var sent=sent.concat(data)
      
}
// document.write(sent)

document.getElementById("greeting-el").textContent=sent
