 function course(details){
    for(let i=0;i<details.length;i++){
       console.log(details[i])
 }
 

}
let myCourses = ["Learn CSS Animations", "UI Design Fundamentals", "Intro to Clean Code"]
course(myCourses)
