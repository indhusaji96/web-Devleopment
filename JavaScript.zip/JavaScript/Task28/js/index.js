
function btnGenerate(){
    var name= document.getElementById("yname").value;

    // let charCodeArr=[];
    var code="";
    for(let i = 0; i < name.length; i++){
         code = code+name.charCodeAt(i);
 
    }
    //  document.getElementById("generator").value=code

   var add=parseInt(code) + 22092022
    // document.getElementById("generator").value=add
 var date= document.getElementById("ydob").value;
date =  date.replace(/-/g, "");
 sum= add + 25092022+date
    document.getElementById("generator").value=sum
 


}