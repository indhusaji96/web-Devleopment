<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</head>
<body style="background-color: #6EA5BE;">
<div>
        <h1 class="text-center mt-5" style="color: brown;">Employee Updation</h1>
        <form action="/employee/update/<?php echo e($id); ?>" method="post" class="text-center " style="margin-top: 50px;">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>
            <div class="border :2px solid black;" style="width: 600px; margin-left: 400px; height: 350px; background-color: #CCB69E; cursor: alias;">

            <div style="margin-left: 40px; margin-top: 30px;">
               Name : <input type="text" id="exampleFormControlInput1" name="name" value="<?php echo e($name); ?>">
            </div>
            <div style="margin-top: 30px;">
               Employee ID :
                <input type="text" id="exampleFormControlInput2" name="id" value="<?php echo e($id); ?>">
            </div>
            <div style="margin-top: 30px; margin-left: 10px;">
               Designation :
                <input type="text" id="exampleFormControlInput3" name="designation" value="<?php echo e($designation); ?>">
            </div>
            <div>
            <button class=" text-center" name="Update" style="margin-top: 40px; border-radius: 12px; padding-left: 10px; background-color: brown; color: white;">Update</button></div>
        </div>
</form>
</body>
</html>

<?php /**PATH C:\Indhu\Laravel\employee-app\resources\views/edit.blade.php ENDPATH**/ ?>