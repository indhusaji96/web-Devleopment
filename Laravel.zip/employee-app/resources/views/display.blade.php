<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>employee list </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</head>
<body>
    <div container style="width :700px; margin: auto;">
    <table class="table" style="border: 1px solid black; background-color: brown; margin-top:100px;">
  <thead >
    <tr style="border: 1px solid black;" >
      <th scope="col" style="background-color : brown; color: white;">Name</th>
       <th scope="col" style="background-color : brown; color: white;">EmployeeID</th> 
      <th scope="col" style="background-color : brown; color: white;">Designation</th> 
     </tr>
  </thead>
  <tbody style="background-color: #CCB69E;" >
  @foreach($employees as $employee)
  <tr><td>{{$employee['name']}}</td>
    <td>{{$employee['id']}}</td>
    <td>{{$employee['designation']}}</td>
    <td style="display: flex;">
        <a href="/employee/edit/{{$employee['id']}}" class="btn btn-info mx-2">Edit</a>
        <form action="/employee/delete/{{$employee['id']}}" method="post"> 
            @csrf  
            @method("DELETE")
        <button class="btn btn-danger">Delete</button>
</form> 
</td>
        
 </tr>
   @endforeach
   
    </tbody>
</table>
</body>
</html>
    