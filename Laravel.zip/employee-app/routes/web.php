<?php

use Illuminate\Support\Facades\Route;
use App\Http\controllers\EmployeeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('register','App\Http\controllers\EmployeeController@create');
Route::post('register','App\Http\controllers\EmployeeController@store');
Route::get('employee','App\Http\controllers\EmployeeController@index');
Route::get('employee/{num}','\App\Http\Controllers\EmployeeController@find');
Route::delete('/employee/delete/{id}','\App\Http\Controllers\EmployeeController@destroy');
Route::get('/employee/edit/{id}','\App\Http\Controllers\EmployeeController@edit');
Route::put('/employee/update/{id}','\App\Http\Controllers\EmployeeController@update');




