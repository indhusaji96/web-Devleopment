<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
   public static function create(){
    return view('register');
   }

   public static function store(Request   $request){
    $formData=$request->validate([
        'name'=>'required',
        'id'=>'required',
        'designation'=>'required'
    ]);
   \App\Models\Employee::create($formData); 
    return redirect('register'); 
}
public static function index(){
    $data=[
        'title'=>'employee_List',
        'employees'=>Employee::all()
    
    ];
    return view('display',$data);
}
public static function find($id) {
    $data=Employee::find($id);
    return view('employee',$data);
   }
   public static function destroy($id){
    $data=Employee::find($id);
    $data->delete();
    return redirect('employee');
   }
   public static function edit($id){
    $data=Employee::find($id);
    return view('edit',$data);
   }
   public static function update(Request   $request, $id){
    $formData=$request->validate([
        'name'=>'required',
        'id'=>'required',
        'designation'=>'required'
    ]);
    $data=Employee::find($id);
    $data->update($formData);
    return redirect('employee');
   }
}
